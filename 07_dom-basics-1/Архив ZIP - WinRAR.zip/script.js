const body = document.body;
const h = document.createElement('h2');
const newInput = document.createElement('input');
      newInput.className = 'new-input';

body.appendChild(h);
body.appendChild(newInput);

newInput.addEventListener('input', () => {
  let newTimer = setTimeout(() => {
    h.textContent = newInput.value;
  }, 3000);
})
